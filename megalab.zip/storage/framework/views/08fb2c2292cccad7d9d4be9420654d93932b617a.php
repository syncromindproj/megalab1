<?php $__env->startSection('content'); ?>


<div class="container">

    <div class="row">
        <div class="col-md-8 col-md-offset-2">

            <div class="panel panel-default">
                <div class="panel-heading">Categoria</div>

                <div class="panel-body">
                    
                    <?php echo Form::open(array('route'=>'categoria.store')); ?>

                        <div class="form-group">
                            <?php echo Form::label('descripcion', 'Ingrese la descripcion'); ?>

                            <?php echo Form::text('descripcion', null, ['class'=>'form-control']); ?>

                        </div>

                        <div class="form-group">
                            <?php echo Form::button('Crear', ['type'=>'submit', 'class'=>'btn btn-primary']); ?>

                        </div>
                    <?php echo Form::close(); ?>

                    
                </div>
            </div>
            <?php if($errors->has('descripcion')): ?>
                <ul class="alert alert-danger">
                    <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </ul>
            <?php endif; ?>
            
        </div>
    </div>
</div>

<script
  src="http://code.jquery.com/jquery-3.2.1.min.js"
  integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
  crossorigin="anonymous"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>