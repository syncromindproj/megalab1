<?php $__env->startSection('content'); ?>


<div class="container">

    <div class="row">
        <div class="col-md-8 col-md-offset-2">

        	<?php if(Session::has("message")): ?>
				<div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
        	<?php endif; ?>

            <div class="panel panel-default">
                <div class="panel-heading">Categoria</div>

                <div class="panel-body">
                    <table class="table" id="myTable">
                        <thead>
                            <tr>
                                <th>Descripcion</th>
                                <th>Acciones</th>
                            </tr>
                        </thead>
                        <tbody>
                    		<?php $__currentLoopData = $categorias; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $categoria): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    			<tr>
									<td><?php echo e($categoria->descripcion); ?></td>
									<td>
										<?php echo Form::open(array('route'=>['categoria.destroy', $categoria->id], 'method'=>'DELETE')); ?>

											<?php echo e(link_to_route('categoria.edit', 'Editar', [$categoria->id], ['class'=>'btn btn-primary'])); ?>

											|
											<?php echo Form::button('Eliminar',['class'=>'btn btn-danger', 'type'=>'submit']); ?>

										<?php echo Form::close(); ?>

									</td>
								</tr>
                    		<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            
                        </tbody>
                    </table>
                    
                </div>
            </div>
			<?php echo e(link_to_route('categoria.create', 'Agregar categoria', null, ['class'=>'btn btn-success'])); ?>

            
        </div>
    </div>
</div>

<script
  src="http://code.jquery.com/jquery-3.2.1.min.js"
  integrity="sha256-hwg4gsxgFZhOsEEamdOYGBf13FyQuiTwlAQgxVSNgt4="
  crossorigin="anonymous"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>