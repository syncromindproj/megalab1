<?php $__env->startSection('content'); ?>


<div class="container">

    <div class="row">
        <div class="col-md-8 col-md-offset-2">

        	<?php if(Session::has("message")): ?>
				<div class="alert alert-success"><?php echo e(Session::get('message')); ?></div>
        	<?php endif; ?>
            <div class="panel panel-default">
                <div class="panel-heading">Subida de archivos</div>

                <div class="panel-body">
                    
                    <form action="ImportarAnalisis" method="post" enctype="multipart/form-data">
                        <label>Subir archivo:</label>
                        
                        <label class="btn btn-default btn-file">
                            Seleccionar archivo <input type="file" name="archivo" style="display: none;">
                        </label>

                        <input type="hidden" value="<?php echo e(csrf_token()); ?>" name="_token">
                        <input type="submit" value="Subir archivo" class="btn btn-primary">
                    </form>

                    
                </div>
            </div>
			<!--<?php echo e(link_to_route('analisis.create', 'Agregar tipo', null, ['class'=>'btn btn-success'])); ?> -->
            <input type="button" id="btn-generar" class="btn btn-success" value="Procesar datos" />
            
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>